package com.example.app_absensi.iu.auth.reset

data class ApiResponse(
    val status: String,
    val message: String
)
