package com.example.app_absensi.iu.auth.login

data class LoginRequest(
    val email: String,
    val password: String
)
