package com.example.app_absensi.iu.attendance.absenmasuk

class AbsenMasukRequest (
    val nama: String,
    val jam_masuk: String,
    val lokasi: String
)
