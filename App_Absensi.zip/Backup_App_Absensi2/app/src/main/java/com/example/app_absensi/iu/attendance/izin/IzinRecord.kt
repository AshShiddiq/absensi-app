package com.example.app_absensi.iu.attendance.izin

data class IzinRecord(
    val id: String,
    val nama: String,
    val tanggal: String,
    val alasan: String
)
