package com.example.app_absensi.iu.attendance

class AbsenResponse (
    val status: String,
    val message: String
)