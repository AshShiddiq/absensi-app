package com.example.app_absensi.iu.attendance.izin

class IzinRequest (
    val nama: String,
    val tanggal: String,
    val alasan: String
)
