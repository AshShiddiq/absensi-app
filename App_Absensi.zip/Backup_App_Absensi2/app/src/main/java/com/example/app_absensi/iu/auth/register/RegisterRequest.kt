package com.example.app_absensi.iu.auth.register

class RegisterRequest(
    val nama: String,
    val jabatan: String,
    val email: String,
    val password: String
)
