package com.example.app_absensi.iu.attendance.absenkeluar

class AbsenKeluarRequest (
    val nama: String,
    val jam_masuk: String,
    val lokasi: String
)
