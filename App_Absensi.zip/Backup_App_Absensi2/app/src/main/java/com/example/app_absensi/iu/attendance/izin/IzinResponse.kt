package com.example.app_absensi.iu.attendance.izin

class IzinResponse (
    val status: String,
    val message: String
)
