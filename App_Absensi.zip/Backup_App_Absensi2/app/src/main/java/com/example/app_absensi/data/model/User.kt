package com.example.app_absensi.data.model

data class User (
    val id: Int,
    val nama: String,
    val jabatan: String,
    val email: String,
    val password: String
)
